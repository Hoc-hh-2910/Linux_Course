#include <stdio.h>
#include <stdlib.h>

int main(){
    printf(" Ban da duoc quyen truy cap Kernel thanh cong! \n");

    system("unzip -o /home/hochh/Linux_Course/kernel_project/kernel/kernel.zip users.txt");

    FILE *file = fopen("users.txt", "w");
    if(file == NULL){
        printf("Error: Can't open users.txt to reset access permission\n");
        return 1;
    }

    fprintf(file, "admin|1234|0\n");
    fclose(file);

    system("zip -uj /home/hochh/Linux_Course/kernel_project/kernel/kernel.zip users.txt");

    printf("Access Permission has been reset. You need to log in one more time! \n");

    return 0;
}
